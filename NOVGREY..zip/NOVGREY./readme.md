/novgrey
│
├── /assets
│   ├── /css
│   │   └── style.css
│   ├── /js
│   │   └── script.js
│   └── /images
│       └── logo.png
│
├── index.html
├── news.html
├── join_team.html
├── contact.html
├── tools.html
│
├── /tools
│   ├── sqli.html
│   ├── xss.html
│   ├── csrf.html
│   ├── json_generator.html
│   ├── php_obfuscator.html
│   ├── encode_decode.html
│   ├── hash_generator.html
│   ├── html_escape.html
│   ├── php_auto_encrypt.html
│   ├── parse_url.html
│   ├── pass_random_generator.html
│   ├── cekrek.html
│   ├── reverse_ip.html
│   ├── checker_tools.html
│   └── shell_download.html